import Progress from '@/components/Progress'
import React from 'react'

const Loading = () => {
  return (
    <Progress/>
  )
}

export default Loading