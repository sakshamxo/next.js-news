import Navbar from "@/components/Navbar";
import "./globals.css";
import { Inter } from "next/font/google";
import SlimNav from "@/components/SlimNav";
import Footer from "@/components/Footer";
import Script from 'next/script'
import Head from 'next/head'


const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Loktantra Udghosh",
  description: "Latest news | daily epaper | national and local news",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <Head>
      <meta name="description" content="Latest news | daily epaper | national and local news"/>
  <meta name="keywords" content="News, Latest news, daily epaper, national and local news "/>
  <meta name="author" content="loktantra udghosh"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
 
    <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6540056585668328"
       crossorigin="anonymous"></script>

  </Head>
      <body className={inter.className}>
        <Navbar />
        <SlimNav />
     
      
        {children}
        <Footer />
      </body>
     
    </html>
  );
}
