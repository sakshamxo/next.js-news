import Refer from "@/components/Refer";
import { Inter } from "next/font/google";
import Head from "next/head";


const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Loktantra Udghosh",
  description: "Latest news | daily epaper | national and local news",
};

export default function RootLayout({ children }) {
  return (
    <>
    <Head>
  <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-6540056585668328"
     crossorigin="anonymous"></script>
</Head>
    <div className="flex flex-col md:flex-row bg-slate-100">
      <div className="w-full">{children}</div>
      <div className="flex w-96 md:w-1/3 p-4 my-8 sm:ml-8 sm:mr-16 border rounded-xl border-slate-200 bg-white">
     
      </div>
    </div>
    </>
  );
}
