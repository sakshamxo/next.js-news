import { getSinglePost, getSinglePostBySlug } from "@/utils/post";
import React from "react";
import { Interweave } from "interweave";
import { Markup } from "interweave";
import * as DOMPurify from "dompurify";
import 'remixicon/fonts/remixicon.css';
import renderHTML from 'react-render-html';
import Image from 'next/image';

const NewsPage = async ({ params }) => {
  const post = await getSinglePost(params.newsId);
  // const post = await getSinglePostBySlug(params.newsId);
  // console.log(post.content.rendered);
  // console.log(post.categories[0])
  let refer = await post?.categories[0]
  console.log(post)

  return (
    <div className="flex flex-col items-center p-4 my-8 sm:ml-16 mx-4  border rounded-xl border-slate-200 bg-white">
      <h1 className="text-xl font-bold ">{renderHTML(post.title.rendered)}</h1>
      <img className="w-full h-auto mt-4" src={post.x_featured_media_large} alt="feature image" />
      <div className="flex items-center w-full justify-between md:flex-row flex-col" >
      <div className="flex items-center w-50 content-evenly mt-4 mb-4" >
      <div className="w-11 h-11 rounded-full overflow-hidden " >
        <img src={post.x_gravatar} alt="author" />
      </div>
      <div className="mx-1 flex md:flex-row flex-col items-center md:justify-evenly">
      <h5 className="md:mx-6 text-xl md:w-50" >{post.x_author}</h5> <h6 className="md:  w-50">{post.x_date}</h6>
      </div>
        </div>
        <div className="flex items-center w-50 justify-center p-4  m-2 rounded">
            <div className="flex gap-4  items-center">
             
              <a
                target="_blank"
                href={`https://www.facebook.com/sharer.php?u=https://www.loktantraudghosh.com/news/${post?.id}}`}
              >
                <i className="ri-facebook-circle-fill text-blue-600 text-3xl"></i>
              </a>
              <a
                target="_blank"
                href={`https://twitter.com/intent/tweet?text=${post?.title.rendered} https://www.loktantraudghosh.com/news/${post?.id} `}
              >
                <i className="ri-twitter-x-fill text-3xl"></i>
              </a>
              <a
                target="_blank"
                href={`https://api.whatsapp.com/send?text=${`*${post?.title.rendered}*https://www.loktantraudghosh.com/news/${post?.id}`}`}
              >
              <i className="ri-whatsapp-fill text-green-600 text-3xl"></i>
              </a>
            </div>
          </div>
      </div>
     
      <div className="w-full h-auto mt-4">
        {/* <Markup content={post.content.rendered} /> */}
       
        {/* <div dangerouslySetInnerHTML={{ __html: post.content.rendered }} /> */}
        {renderHTML(post.content.rendered )}
       
        {/* <Interweave content={ post.content.rendered } /> */}
      
      </div>
      
      {/* <div>{post.content.rendered}</div> */}
      <div className="flex items-center w-50 justify-center w-full md:p-4 px-10 border  m-2 rounded-xl">
            <div className="flex gap-4 items-center">
             <h2 className="md:text-xl text-xs" >Keep on Sharing:</h2>
              <a
                target="_blank"
                href={`https://www.facebook.com/sharer.php?u=https://www.loktantraudghosh.com/news/${post?.id}}`}
              >
                <i className="ri-facebook-circle-fill text-blue-600 text-3xl"></i>
              </a>
              <a
                target="_blank"
                href={`https://twitter.com/intent/tweet?text=${post?.title.rendered} https://www.loktantraudghosh.com/news/${post?.id} `}
              >
                <i className="ri-twitter-x-fill text-3xl"></i>
              </a>
              <a
                target="_blank"
                href={`https://api.whatsapp.com/send?text=${`*${post?.title.rendered}*https://www.loktantraudghosh.com/news/${post?.id}`}`}
              >
              <i className="ri-whatsapp-fill text-green-600 text-3xl"></i>
              </a>
            </div>
          </div>
    </div>
  );
};

export default NewsPage;
