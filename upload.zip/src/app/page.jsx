import PostCard from "@/components/PostCard";
import Posts from "@/components/Posts";
import { getPost, getPostWithOffset } from "@/utils/post";


export default async function Home() {
  const posts = await getPost(5, "posts");
  const posts2 = await getPostWithOffset(5, "posts");
  const posts3 = await getPostWithOffset(10, "posts");

  return (
    <main className="">
      <div className="flex flex-col justify-around px-1 mt-6 sm:px-16 sm:flex-row sm:gap-4">
        <div>
          {posts.map((post, index) => (
            <>
              <PostCard
                key={post.id}
                title={post.title.rendered}
                fullImage={
                  post.x_featured_media
                    ? post.x_featured_media
                    : "/placeholder.png"
                  // post.blog_post_layout_featured_media_urls?.full?.[0] || "/placeholder.png"
                }
                small={index === 0 ? false : true}
                id={post.id}
              />
            </>
          ))}
        </div>
        <div>
          {posts2.map((post, index) => (
            <>
              <PostCard
                key={post.id}
                title={post.title.rendered}
                fullImage={
                  post.x_featured_media
                    ? post.x_featured_media
                    : "/placeholder.png"
                  // post.blog_post_layout_featured_media_urls?.full?.[0] || "/placeholder.png"
                }
                small={index === 0 ? false : true}
                id={post.id}
              />
            </>
          ))}
        </div>
        <div>
          {posts3.map((post, index) => (
            <>
              <PostCard
                key={post.id}
                title={post.title.rendered}
                fullImage={
                  post.x_featured_media
                    ? post.x_featured_media
                    : "/placeholder.png"
                  // post.blog_post_layout_featured_media_urls?.full?.[0] || "/placeholder.png"
                }
                small={index === 0 ? false : true}
                id={post.id}
              />
            </>
          ))}
        </div>
      </div>
    </main>
  );
}
