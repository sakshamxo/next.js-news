import Progress from '@/components/Progress'
import React from 'react'

const loading = () => {
  return (
    <Progress/>
  )
}

export default loading