import React from "react";

const Footer = () => {
  return (
    // mobile footer
    <div className="sticky left-0 bottom-0 flex w-full flex-row justify-around h-16 transition duration-500 ease-in bg-white sm:hidden ">
      <div className="flex flex-col items-center justify-center gap-1 p-2 m-2">
        <img src="/Home1.png" alt="होम" className="w-4 h-4" />
        <h2>होम</h2>
      </div>
   
      <div className="flex flex-col items-center justify-center gap-1 p-2 m-2">
        <img src="/Show1.png" alt="देखिये" className="w-4 h-4" />
        <h2>देखिये</h2>
      </div>
      <div className="flex flex-col items-center justify-center gap-1 p-2 m-2">
        <img src="/Listen1.png" alt="सुनिए" className="w-4 h-4" />
        <h2>सुनिए</h2>
      </div>
      <div className="flex flex-col items-center justify-center gap-1 p-2 m-2">
        <img src="/Read1.png" alt="पढ़िए" className="w-4 h-4" />
        <h2>ई पेपर</h2>
      </div>
    </div>

    // mobile footer end
  );
};

export default Footer;
