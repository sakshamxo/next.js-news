import axios from "axios";
import Link from "next/link";
import { getMenu } from "@/utils/post";
// export const revalidate = 1; // revalidate at most every hour

export const dynamic = "force-dynamic";


const SlimNav = async () => {
  // https://loktantraudghosh.com/wp-json/menus/v1/menus/front-menu

  const menu = await getMenu();
 
  // console.log(menu)
  return (
    <div className="flex">
        {
          <ul className="flex w-full gap-2 pb-1 overflow-scroll text-sm snap-mandatory md:items-center md:justify-center">
            {menu.items.map((item, index) => (
                <Link key={index} href={"/all/" + item.object_id}>
              <li  className="px-2 py-1 rounded cursor-pointer bg-lime-200 hover:bg-lime-300 whitespace-nowrap">
                {item.title}
                {/* {item.object_id} */}
              </li>
                </Link>
            ))}
          
          </ul>
        }
      </div>
  );
};

export default SlimNav;
