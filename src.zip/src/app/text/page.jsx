import React from 'react'
import RootLayout from '../layout'
import ComingSoon from '@/components/ComingSoon'
const page = () => {
  return (

        <ComingSoon/>
    
  )
}

export default page