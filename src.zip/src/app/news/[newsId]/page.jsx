import { getSinglePost, getSinglePostBySlug } from "@/utils/post";
import React from "react";
import { Interweave } from "interweave";
import { Markup } from "interweave";

const NewsPage = async ({ params }) => {
  const post = await getSinglePost(params.newsId);
  // const post = await getSinglePostBySlug(params.newsId);
  // console.log(post.content.rendered);

  return (
    <div className="flex flex-col p-4 my-8 sm:ml-16 mx-4  border rounded-xl border-slate-200">
      <h1 className="text-xl font-bold ">{post.title.rendered}</h1>
      <div className="">
        {/* <Markup content={post.content.rendered} /> */}
        <div dangerouslySetInnerHTML={{ __html: post.content.rendered }} />
        {/* <Interweave content= /> */}
      </div>
      {/* <div>{post.content.rendered}</div> */}
    </div>
  );
};

export default NewsPage;
