import { Inter } from "next/font/google";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Loktantra Udghosh",
  description: "Latest news | daily epaper | national and local news",
};

export default function RootLayout({ children }) {
  return (
    <div className="flex flex-col sm:flex-row">
      <div className="w-full">{children}</div>
      <div className="flex w-1/3 p-4 my-8 sm:ml-8 sm:mr-16 border rounded-xl border-slate-200">
        sidebar
      </div>
    </div>
  );
}
