import Navbar from "@/components/Navbar";
import "./globals.css";
import { Inter } from "next/font/google";
import SlimNav from "@/components/SlimNav";
import Footer from "@/components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata = {
  title: "Loktantra Udghosh",
  description: "Latest news | daily epaper | national and local news",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Navbar />
        <SlimNav />
        {children}
        <Footer />
      </body>
    </html>
  );
}
