import ComingSoon from '@/components/ComingSoon'
import React from 'react'

const page = () => {
  return (
    <ComingSoon/>
  )
}

export default page