import Link from "next/link";

const PostCard = ({
  first,
  fullImage,
  title,
  postImageUrl,
  categoryName,
  categoryId,
  url,
  id,
  shareUrl,
  small,
}) => {
  return (
    <Link href={"/news/" + id}>
     <div
      className={
        small ? "flex gap-2 p-1  border-b" : "flex flex-col gap-2 p-1 "
      }
    >
      <img
        alt={title}
        src={fullImage ? fullImage : "/placeholder.png"}
        className={
          small
            ? "border rounded shadow h-16 aspect-video object-cover max-w-fit border-slate-300"
            : "border rounded shadow h-52 aspect-video object-cover max-w-fit border-slate-300 "
        }
      />

      <h3
        className={
          small
            ? " text-sm font-bold line-clamp-3"
            : "text-sm font-bold line-clamp-1"
        }
      >
        {title}
      </h3>
    </div>
    </Link>
   
  );
};

export default PostCard;
