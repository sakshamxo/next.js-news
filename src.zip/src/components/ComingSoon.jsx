const ComingSoon = () => {
  return( <div className="w-full flex flex-col items-center h-96" >
    <h1 className="text-3xl font-semibold" >Coming Soon</h1>
    <p>Stay tuned for more news</p>
  </div>);
};

export default ComingSoon;
